<?php
require_once 'clases/respuestas.class.php';
require_once 'clases/lenguaje.class.php';
require_once 'clases/conexion/configCors.php';

$headers = getallheaders();

$_respuestas = new respuestas;
$_lenguaje = new lenguaje;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($headers["token"])) {
        $token = $headers["token"];
        $lstlenguaje = $_lenguaje->listarLenguajes($token);
        echo json_encode($lstlenguaje);
        http_response_code(200);
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else {

    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
}
