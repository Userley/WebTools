<?php

class respuestas
{

    public $response = [
        "status" => "ok",
        "result" => array()
    ];

    public function error_405()
    {
        $this->response['status'] = "error";
        $this->response['result'] = array(
            "code" => "405",
            "message" => "Método no permitido"
        );

        return $this->response;
    }

    public function error_200($string = "Datos incorrectos")
    {
        $this->response['status'] = "error";
        $this->response['result'] = array(
            "code" => "200",
            "message" => $string
        );

        return $this->response;
    }

    public function error_400()
    {
        $this->response['status'] = "error";
        $this->response['result'] = array(
            "code" => "400",
            "message" => "Datos enviados incompletos o con formato incorrecto"
        );

        return $this->response;
    }

    public function error_401($string = "No autorizado, Token invalido")
    {
        $this->response['status'] = "error";
        $this->response['result'] = array(
            "code" => "401",
            "message" => $string
        );

        return $this->response;
    }

    public function error_500($string = "Error interno en el servidor")
    {
        $this->response['status'] = "error";
        $this->response['result'] = array(
            "code" => "500",
            "message" => $string
        );

        return $this->response;
    }
}
