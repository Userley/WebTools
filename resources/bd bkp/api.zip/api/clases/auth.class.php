<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';

class auth extends conexion
{
    public function login($json)
    {
        $_respuestas = new respuestas;
        $datos = json_decode($json, true);
        if (!isset($datos['usuario']) || !isset($datos['password'])) {
            #  Error con los campos
            return $_respuestas->error_400();
        } else {
            #  Respuesta OK
            $usuario = $datos['usuario'];
            $password = $datos['password'];
            $password = parent::encriptar($password);
            $datos = $this->ObtenerDatosUsuario($usuario);
            if ($datos) {
                #  Si existe usuario
                #  Verificar si la contraseña es igual a lo almacenado en la BD
                if ($password == $datos[0]['password']) {

                    if ($datos[0]['estado'] == 1) {

                        #  Crear el TOKEN
                        $verificar = $this->insertarToken($datos[0]);
                        // echo var_dump($verificar);
                        if ($verificar) {

                            # Se guardó token
                            $result = $_respuestas->response;
                            $result["result"] = array(
                                "token" => $verificar["Token"],
                                "id" => $verificar["IdUser"],
                                "nombres" => $verificar["Nombres"],
                                "avatar" => $verificar["Avatar"]
                            );
                            return $result;
                        } else {
                            # Error de almacenamiento de token
                            return $_respuestas->error_500("Error interno, no hemos podido guardar el token.");
                        }
                    } else {
                        # Usuario inactivo
                        return $_respuestas->error_200("Usuario inactivo.");
                    }
                } else {
                    # Password inválido
                    return $_respuestas->error_200("El password es invalido!.");
                }
            } else {
                # No existe usuario
                return $_respuestas->error_200("El usuario $usuario no existe");
            }
        }
    }

    private function ObtenerDatosUsuario($correo)
    {
        $query = "SELECT idusuario,avatar,nombres,apellidos, password, estado FROM usuario WHERE correo = '$correo'";
        $datos = parent::obtenerDatos($query);
        if (isset($datos[0]["idusuario"])) {
            return $datos;
        } else {
            return 0;
        }
    }

    private function insertarToken($usuario)
    {
        $val = "U$3RL3Y";
        $Token = bin2hex(openssl_random_pseudo_bytes(16, $val));
        $date = date("Y-m-d H:i");
        $estado = 1;
        $query = "INSERT INTO usuarios_token (idusuario,token,estado,fecha) VALUES ('" . $usuario["idusuario"] . "','$Token',$estado,'$date')";
        $verifica = parent::nonQuery($query);


        if ($verifica) {
            $dataLogin = array();

            $dataLogin["Token"] = $Token;
            $dataLogin["IdUser"] = $usuario["idusuario"];
            $dataLogin["Avatar"] = $usuario["avatar"];
            $dataLogin["Nombres"] = $usuario["nombres"] . " " . $usuario["apellidos"];
            return $dataLogin;
        } else {
            return 0;
        }
    }
}
