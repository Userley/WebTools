<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';


class utilcode extends conexion
{

    private $table = "code_registro";
    private $token = "";
    private $idcodereg = 0;
    private $idlenguaje = 1;
    private $idusuario = 1;
    private $titulo = "";
    private $referencia = "";
    private $imagen_err = "";
    private $solucion = "";
    private $imagen_sol = "";
    private $fechareg = "";
    private $adjunto1 = "";
    private $adjunto2 = "";
    private $calificacion = 0;
    private $tag = "";
    private $estado = 1;

    public function listarCodeUtils($pagina = 0, $token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            $inicio = 0;
            $cantidad = 100;
            if ($pagina > 1) {
                $inicio = ($cantidad * ($pagina - 1)) + 1;
                $cantidad = $cantidad * $pagina;
            }

            $query = "SELECT cr.idcodereg,cr.titulo,cr.referencia,cr.imagen_err, cr.solucion, cr.imagen_sol, cr.fechareg, cr.tag,cr.idlenguaje,lg.nombre, lg.logo, cr.calificacion,cr.adjunto1, cr.adjunto2, cr.estado from " . $this->table . " cr INNER JOIN lenguaje lg ON lg.idlenguaje = cr.idlenguaje WHERE cr.estado = " . $this->estado . " and cr.idusuario = " . $this->idusuario . " ORDER BY cr.fechareg DESC"; // LIMIT $inicio,$cantidad";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    public function obtenerCodeUtil($id)
    {
        $query = "SELECT cr.idcodereg,cr.titulo,cr.referencia,cr.imagen_err, cr.solucion, cr.imagen_sol, cr.fechareg, cr.tag,cr.idlenguaje,lg.nombre, lg.logo, cr.calificacion,cr.adjunto1, cr.adjunto2, cr.estado from " . $this->table . " cr INNER JOIN lenguaje lg ON lg.idlenguaje = cr.idlenguaje WHERE idcodereg = '$id' ";
        return parent::obtenerDatos($query);
    }


    public function post($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['titulo'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                if (isset($datos['idlenguaje'])) {
                    $this->idlenguaje = $datos['idlenguaje'];
                }
                if (isset($datos['idusuario'])) {
                    $this->idusuario = $datos['idusuario'];
                }
                if (isset($datos['titulo'])) {
                    $this->titulo = $datos['titulo'];
                }
                if (isset($datos['referencia'])) {
                    $this->referencia = $datos['referencia'];
                }
                if (isset($datos['imagen_err'])) {
                    $this->imagen_err = $datos['imagen_err'];
                }
                if (isset($datos['solucion'])) {
                    $this->solucion = $datos['solucion'];
                }
                if (isset($datos['imagen_sol'])) {
                    $this->imagen_sol = $datos['imagen_sol'];
                }
                if (isset($datos['fechareg'])) {
                    $this->fechareg = $datos['fechareg'];
                }
                if (isset($datos['tag'])) {
                    $this->tag = $datos['tag'];
                }
                if (isset($datos['adjunto1'])) {
                    $this->adjunto1 = $datos['adjunto1'];
                }
                if (isset($datos['adjunto2'])) {
                    $this->adjunto2 = $datos['adjunto2'];
                }
                if (isset($datos['calificacion'])) {
                    $this->calificacion = $datos['calificacion'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->insertarCodeUtil();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idcodereg" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function insertarCodeUtil()
    {
        $query = "INSERT INTO " . $this->table . " (idlenguaje, 
                                                    idusuario, 
                                                    titulo, 
                                                    referencia, 
                                                    imagen_err, 
                                                    solucion, 
                                                    imagen_sol, 
                                                    fechareg, 
                                                    tag, 
                                                    adjunto1,
                                                    adjunto2,
                                                    calificacion, 
                                                    estado) VALUES 
                                                    ('$this->idlenguaje','$this->idusuario','$this->titulo','$this->referencia','$this->imagen_err','$this->solucion','$this->imagen_sol','$this->fechareg','$this->tag','$this->adjunto1','$this->adjunto2','$this->calificacion',$this->estado)";

        $resp = parent::nonQueryId($query);

        if ($resp) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function put($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['titulo'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                $this->idcodereg = $datos['idcodereg'];
                $this->titulo = $datos['titulo'];
                if (isset($datos['referencia'])) {
                    $this->referencia = $datos['referencia'];
                }
                if (isset($datos['imagen_err'])) {
                    $this->imagen_err = $datos['imagen_err'];
                }
                if (isset($datos['solucion'])) {
                    $this->solucion = $datos['solucion'];
                }
                if (isset($datos['imagen_sol'])) {
                    $this->imagen_sol = $datos['imagen_sol'];
                }
                if (isset($datos['fechareg'])) {
                    $this->fechareg = $datos['fechareg'];
                }
                if (isset($datos['tag'])) {
                    $this->tag = $datos['tag'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->actualizarCodeUtil();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idcodereg" => $this->idcodereg,
                        "updated" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function actualizarCodeUtil()
    {
        $query = "UPDATE " . $this->table . " SET titulo = '$this->titulo', 
                                                    referencia = '$this->referencia', 
                                                    imagen_err = '$this->imagen_err', 
                                                    solucion = '$this->solucion', 
                                                    imagen_sol = '$this->imagen_sol', 
                                                    tag = '$this->tag', 
                                                    estado = $this->estado 
                                                WHERE idcodereg = '$this->idcodereg'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function delete($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['idcodereg'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                $this->idcodereg = $datos['idcodereg'];


                $resp = $this->eliminarCodeUtil();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idcodereg" => $this->idcodereg,
                        "deleted" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function eliminarCodeUtil()
    {
        $query = "DELETE FROM " . $this->table . " WHERE idcodereg = '$this->idcodereg'";
        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    private function buscarToken()
    {
        $query = "SELECT idtoken, idusuario, estado FROM usuarios_token WHERE Token = '" . $this->token . "' AND estado = 1";
        $resp = parent::obtenerDatos($query);

        if ($resp) {
            return  $resp;
        } else {
            return 0;
        }
    }

    private function actualizarToken($tokenId)
    {
        $date = date("Y-m-d H:i");
        $query = "UPDATE usuarios_token SET fecha = '$date' WHERE idtoken = '$tokenId'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }
}
