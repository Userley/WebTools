<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';


class usuario extends conexion
{

    private  $tableUsuario = "usuario";
    private  $token = "";
    private  $idusuario = 0;
    private  $nombres = "";
    private  $apellidos = "";
    private  $avatar = "";
    private  $nickname = "";
    private  $password = "";
    private  $correo = "";
    private  $celular = "";
    private  $fechanac = "1987-03-21";
    private  $tipousuario = "";
    private  $estado = 1;
    //idusuario, nombres, apellidos, avatar, nickname, password, correo, celular, fechanac, tipousuario, estado 

    public function getUsuarios($token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            // $inicio = 0;
            // $cantidad = 100;
            // if ($pagina > 1) {
            //     $inicio = ($cantidad * ($pagina - 1)) + 1;
            //     $cantidad = $cantidad * $pagina;
            // }

            $query = "SELECT idusuario,nombres,apellidos,avatar,nickname,password,correo,celular,fechanac,tipousuario,estado FROM " . $this->tableUsuario . " where estado = " . $this->estado;// . " LIMIT $inicio,$cantidad";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    public function getUsuarioById($id)
    {
        $query = "SELECT * FROM " . $this->tableUsuario . " WHERE idusuario = '$id' ";
        return parent::obtenerDatos($query);
    }


    public function post($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {

            if (!isset($datos['nombres']) || !isset($datos['apellidos']) || !isset($datos['avatar']) || !isset($datos['nickname']) || !isset($datos['password']) || !isset($datos['correo']) || !isset($datos['celular']) || !isset($datos['fechanac'])) {
                return $_respuesta->error_400();
            } else {
                if (isset($datos['nombres'])) {
                    $this->nombres = $datos['nombres'];
                }
                if (isset($datos['apellidos'])) {
                    $this->apellidos = $datos['apellidos'];
                }
                if (isset($datos['avatar'])) {
                    $this->avatar = $datos['avatar'];
                }
                if (isset($datos['nickname'])) {
                    $this->nickname = $datos['nickname'];
                }
                if (isset($datos['password'])) {
                    $this->password = $datos['password'];
                }
                if (isset($datos['correo'])) {
                    $this->correo = $datos['correo'];
                }
                if (isset($datos['celular'])) {
                    $this->celular = $datos['celular'];
                }
                if (isset($datos['fechanac'])) {
                    $this->fechanac = $datos['fechanac'];
                }
                if (isset($datos['tipousuario'])) {
                    $this->tipousuario = $datos['tipousuario'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->insertarUsuario();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idusuario" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function insertarUsuario()
    {

        $query = "INSERT INTO " . $this->tableUsuario . " (nombres, apellidos, avatar, nickname, password, correo, celular, fechanac, tipousuario, estado) VALUES 
                                                    ('$this->nombres','$this->apellidos','$this->avatar','$this->nickname','$this->password','$this->correo','$this->celular','$this->fechanac','$this->tipousuario',$this->estado)";
        $resp = parent::nonQueryId($query);
        if ($resp) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function put($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['idusuario'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                if (isset($datos['idusuario'])) {
                    $this->idusuario = $datos['idusuario'];
                }
                if (isset($datos['nombres'])) {
                    $this->nombres = $datos['nombres'];
                }
                if (isset($datos['apellidos'])) {
                    $this->apellidos = $datos['apellidos'];
                }
                if (isset($datos['avatar'])) {
                    $this->avatar = $datos['avatar'];
                }
                if (isset($datos['nickname'])) {
                    $this->nickname = $datos['nickname'];
                }
                if (isset($datos['password'])) {
                    $this->password = $datos['password'];
                }
                if (isset($datos['correo'])) {
                    $this->correo = $datos['correo'];
                }
                if (isset($datos['celular'])) {
                    $this->celular = $datos['celular'];
                }
                if (isset($datos['fechanac'])) {
                    $this->fechanac = $datos['fechanac'];
                }
                if (isset($datos['tipousuario'])) {
                    $this->tipousuario = $datos['tipousuario'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->actualizarUsuario();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idusuario" => $this->idusuario,
                        "updated" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function actualizarUsuario()
    {

        $query = "UPDATE " . $this->tableUsuario . " SET nombres = '$this->nombres', 
                                                apellidos = '$this->apellidos', 
                                                avatar = '$this->avatar', 
                                                nickname = '$this->nickname', 
                                                password = '$this->password', 
                                                correo = '$this->correo', 
                                                celular = '$this->celular',
                                                fechanac = '$this->fechanac', 
                                                tipousuario = '$this->tipousuario', 
                                                estado = $this->estado  
                                                WHERE idusuario = '$this->idusuario'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function delete($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['idusuario'])) { 
                return $_respuesta->error_400();
            } else {

                $this->idusuario = $datos['idusuario'];


                $resp = $this->eliminarUsuario();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idusuario" => $this->idusuario,
                        "deleted" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function eliminarUsuario()
    {

        $query = "DELETE FROM " . $this->tableUsuario . " WHERE idusuario = '$this->idusuario'";
        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    private function buscarToken()
    {
        $query = "SELECT idtoken, idusuario, estado FROM usuarios_token WHERE Token = '" . $this->token . "' AND estado = 1";
        $resp = parent::obtenerDatos($query);
        if ($resp) {
            return  $resp;
        } else {
            return 0;
        }
    }

    private function actualizarToken($tokenId)
    {
        $date = date("Y-m-d H:i");
        $query = "UPDATE usuarios_token SET fecha = '$date' WHERE idtoken = '$tokenId'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }
 }
