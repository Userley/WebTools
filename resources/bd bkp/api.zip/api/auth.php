<?php
require_once 'clases/auth.class.php';
require_once 'clases/respuestas.class.php';
require_once 'clases/conexion/configCors.php';

$_auth = new auth;
$_respuestas = new respuestas;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    # Recibir datos
    // $postBody = file_get_contents("php://input");
    if (!isset($_GET["usuario"]) || !isset($_GET["password"])) {
        $datosArray = $_respuestas->error_405();
        echo json_encode($datosArray);
    } else {
        $usuario = $_GET["usuario"];
        $password = $_GET["password"];

        # Enviamos los datos al manejador
        $postBody = array(
            "usuario" => $usuario,
            "password" => $password
        );
        $datosArray = $_auth->login(json_encode($postBody));
        // echo var_dump($datosArray);
        # Devolvemos respuestas

        if (isset($datosArray["result"]["code"])) {
            $reponseCode = $datosArray["result"]["code"];
            http_response_code($reponseCode);
        } else {
            http_response_code(200);
        }

        echo json_encode($datosArray);
    }
} else {
    header('Content-type:application/json');
    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
}
