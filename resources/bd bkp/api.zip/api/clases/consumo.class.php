<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';


class consumo extends conexion
{

    private $tableConsumo = "consumo";

    private $tableDetalleConsumo = "consumo_detalle";


    private $idusuario = 0;
    private $idmes = 0;
    private $idanio = 0;
    private $medidakw = 0;
    private $costokw = 0;
    private $igv = 0;
    private $consumokwtotal = 0;
    private $consumorecibo = 0;
    private $montorecibo = 0;
    private $precioxkw = 0;
    private $costoadministrativo = 0;
    private $costoadministrativototal = 0;
    private $costofraccionamiento = 0;
    private $costofraccionamientototal = 0;
    private $costototalconsumo = 0;

    private $consumokw = 0;
    private $montototalsinigv = 0;
    private $montoigv = 0;
    private $montototalconigv = 0;
    private $montocostoadministrativo = 0;
    private $montopagofraccionado = 0;
    private $montototal = 0;
    private $idconsumo = 0;


    // private $token = "";
    // private $idcodereg = 0;
    // private $idlenguaje = 1;
    // private $idusuario = 9;
    // private $titulo = "";
    // private $referencia = "";
    // private $imagen_err = "";
    // private $solucion = "";
    // private $imagen_sol = "";
    // private $fechareg = "";
    // private $adjunto1 = "";
    // private $adjunto2 = "";
    // private $calificacion = 0;
    // private $tag = "";
    // private $estado = 1;




    public function listarAnios($token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            $query = "SELECT 
                        idanio, 
                        descripcion
                    FROM anios 
                    ORDER BY idanio DESC";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }


    public function listarMeses($token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            $query = "SELECT 
                        idmes, 
                        descripcion
                    FROM meses 
                    ORDER BY idmes DESC";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }




    public function listarConsumos($token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            // $inicio = 0;
            // $cantidad = 100;
            // if ($pagina > 1) {
            //     $inicio = ($cantidad * ($pagina - 1)) + 1;
            //     $cantidad = $cantidad * $pagina;
            // }

            $query = "SELECT 
                        c.idconsumo, 
                        c.idmes, 
                        m.descripcion AS mes, 
                        c.idanio, 
                        a.descripcion as anio, 
                        c.consumokwtotal, 
                        c.precioxkw, 
                        c.costoadministrativo, 
                        c.costofraccionamiento, 
                        c.costototalconsumo,
                        c.igv 
                    FROM consumo c
                        INNER JOIN meses m ON m.idmes=c.idmes
                        INNER JOIN anios a ON a.idanio = c.idanio
                    ORDER BY a.idanio,c.idmes DESC";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }



    public function listarDetalleConsumo($idConsumo = 0, $token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {

            $query = "SELECT
            cd.idusuario, 
            u.nombres AS usuario, 
            m.Idmes, 
            m.descripcion AS mes, 
            a.idanio, 
            a.descripcion AS anio, 
            cd.medidakw,
            cd.costokw,
            cd.igv,
            cd.consumokw,
            cd.montototalsinigv,
            cd.montoigv,
            cd.montototalconigv,
            cd.montocostoadministrativo,
            cd.montopagofraccionado,
            cd.montototal
            FROM consumo_detalle cd
            INNER JOIN meses m ON m.idmes = cd.idmes
            INNER JOIN anios a ON a.idanio = cd.idanio
            INNER JOIN usuario u ON u.idusuario = cd.idusuario
            WHERE cd.idconsumo = " . $idConsumo . "
            ORDER BY a.idanio,cd.idmes ASC";

            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    // public function obtenerCodeUtil($id)
    // {
    //     $query = "SELECT cr.idcodereg,cr.titulo,cr.referencia,cr.imagen_err, cr.solucion, cr.imagen_sol, cr.fechareg, cr.tag,cr.idlenguaje,lg.nombre, lg.logo, cr.calificacion,cr.adjunto1, cr.adjunto2, cr.estado from " . $this->table . " cr INNER JOIN lenguaje lg ON lg.idlenguaje = cr.idlenguaje WHERE idcodereg = '$id' ";
    //     return parent::obtenerDatos($query);
    // }


    public function post($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['idusuario'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {


                if (isset($datos['idusuario'])) {
                    $this->idusuario = $datos['idusuario'];
                }
                if (isset($datos['idmes'])) {
                    $this->idmes = $datos['idmes'];
                }
                if (isset($datos['idanio'])) {
                    $this->idanio = $datos['idanio'];
                }
                if (isset($datos['consumorecibo'])) {
                    $this->consumorecibo = $datos['consumorecibo'];
                }

                if (isset($datos['montorecibo'])) {
                    $this->montorecibo = $datos['montorecibo'];
                }
                if (isset($datos['consumokwtotal'])) {
                    $this->consumokwtotal = $datos['consumokwtotal'];
                }
                if (isset($datos['precioxkw'])) {
                    $this->precioxkw = $datos['precioxkw'];
                }
                if (isset($datos['costoadministrativo'])) {
                    $this->costoadministrativo = $datos['costoadministrativo'];
                }
                if (isset($datos['costoadministrativototal'])) {
                    $this->costoadministrativototal = $datos['costoadministrativototal'];
                }
                if (isset($datos['costofraccionamiento'])) {
                    $this->costofraccionamiento = $datos['costofraccionamiento'];
                }
                if (isset($datos['costofraccionamientototal'])) {
                    $this->costofraccionamientototal = $datos['costofraccionamientototal'];
                }
                if (isset($datos['igv'])) {
                    $this->igv = $datos['igv'];
                }

                $resp = $this->insertarConsumo();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "registrado" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function insertarConsumo()
    {
        $query = "CALL registrar_consumo ('$this->idusuario','$this->idmes','$this->idanio','$this->consumorecibo','$this->montorecibo','$this->consumokwtotal','$this->precioxkw','$this->costoadministrativo','$this->costoadministrativototal','$this->costofraccionamiento','$this->costofraccionamientototal','$this->igv');";

        $resp = parent::nonQuery($query);
        if ($resp) {
            return $resp;
        } else {
            return 0;
        }
    }


    // public function put($json, $token)
    // {
    //     $_respuesta = new respuestas;
    //     $datos = json_decode($json, true);

    //     if (!isset($token)) {
    //         return $_respuesta->error_401();
    //     } else {
    //         $this->token = $token;
    //         $arrayToken = $this->buscarToken();
    //     }
    //     if ($arrayToken) {
    //         if (!isset($datos['titulo'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
    //             return $_respuesta->error_400();
    //         } else {

    //             $this->idcodereg = $datos['idcodereg'];
    //             $this->titulo = $datos['titulo'];
    //             if (isset($datos['referencia'])) {
    //                 $this->referencia = $datos['referencia'];
    //             }
    //             if (isset($datos['imagen_err'])) {
    //                 $this->imagen_err = $datos['imagen_err'];
    //             }
    //             if (isset($datos['solucion'])) {
    //                 $this->solucion = $datos['solucion'];
    //             }
    //             if (isset($datos['imagen_sol'])) {
    //                 $this->imagen_sol = $datos['imagen_sol'];
    //             }
    //             if (isset($datos['fechareg'])) {
    //                 $this->fechareg = $datos['fechareg'];
    //             }
    //             if (isset($datos['tag'])) {
    //                 $this->tag = $datos['tag'];
    //             }
    //             if (isset($datos['estado'])) {
    //                 $this->estado = $datos['estado'];
    //             }

    //             $resp = $this->actualizarCodeUtil();
    //             if ($resp) {
    //                 $respuesta = $_respuesta->response;
    //                 $respuesta["result"] = array(
    //                     "idcodereg" => $this->idcodereg,
    //                     "updated" => $resp
    //                 );
    //                 return $respuesta;
    //             } else {
    //                 return $_respuesta->error_500();
    //             }
    //         }
    //     } else {
    //         return $_respuesta->error_401("El token enviado no es válido o caducó");
    //     }
    // }

    // private function actualizarCodeUtil()
    // {
    //     $query = "UPDATE " . $this->table . " SET titulo = '$this->titulo', 
    //                                                 referencia = '$this->referencia', 
    //                                                 imagen_err = '$this->imagen_err', 
    //                                                 solucion = '$this->solucion', 
    //                                                 imagen_sol = '$this->imagen_sol', 
    //                                                 tag = '$this->tag', 
    //                                                 estado = $this->estado 
    //                                             WHERE idcodereg = '$this->idcodereg'";

    //     $resp = parent::nonQuery($query);
    //     if ($resp >= 1) {
    //         return $resp;
    //     } else {
    //         return 0;
    //     }
    // }


    // public function delete($json, $token)
    // {
    //     $_respuesta = new respuestas;
    //     $datos = json_decode($json, true);

    //     if (!isset($token)) {
    //         return $_respuesta->error_401();
    //     } else {
    //         $this->token = $token;
    //         $arrayToken = $this->buscarToken();
    //     }
    //     if ($arrayToken) {
    //         if (!isset($datos['idcodereg'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
    //             return $_respuesta->error_400();
    //         } else {

    //             $this->idcodereg = $datos['idcodereg'];


    //             $resp = $this->eliminarCodeUtil();
    //             if ($resp) {
    //                 $respuesta = $_respuesta->response;
    //                 $respuesta["result"] = array(
    //                     "idcodereg" => $this->idcodereg,
    //                     "deleted" => $resp
    //                 );
    //                 return $respuesta;
    //             } else {
    //                 return $_respuesta->error_500();
    //             }
    //         }
    //     } else {
    //         return $_respuesta->error_401("El token enviado no es válido o caducó");
    //     }
    // }

    // private function eliminarCodeUtil()
    // {
    //     $query = "DELETE FROM " . $this->table . " WHERE idcodereg = '$this->idcodereg'";
    //     $resp = parent::nonQuery($query);
    //     if ($resp >= 1) {
    //         return $resp;
    //     } else {
    //         return 0;
    //     }
    // }


    private function buscarToken()
    {
        $query = "SELECT idtoken, idusuario, estado FROM usuarios_token WHERE Token = '" . $this->token . "' AND estado = 1";
        $resp = parent::obtenerDatos($query);

        if ($resp) {
            return  $resp;
        } else {
            return 0;
        }
    }

    private function actualizarToken($tokenId)
    {
        $date = date("Y-m-d H:i");
        $query = "UPDATE usuarios_token SET fecha = '$date' WHERE idtoken = '$tokenId'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }
}
