<?php
require_once 'clases/respuestas.class.php';
require_once 'clases/usuario.class.php';
require_once 'clases/conexion/configCors.php';

$headers = getallheaders();

$_respuestas = new respuestas;
$_usuario = new usuario;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($headers["token"])) {
        $token = $headers["token"];

        if (isset($_GET["id"])) {
            $utilUserId = $_GET["id"];
            $datosUsuario = $_usuario->getUsuarioById($utilUserId, $token);
            echo json_encode($datosUsuario);
            http_response_code(200);
        } else {
            $lstutilCode = $_usuario->getUsuarios($token);
            echo json_encode($lstutilCode);
            http_response_code(200);
        }
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $post_body = file_get_contents("php://input");

    if (isset($headers["token"])) {
        $token = $headers["token"];

        # Enviamos los datos
        $resp = $_usuario->post($post_body, $token);
        if (isset($resp["result"]["code"])) {
            $reponseCode = $resp["result"]["code"];
            http_response_code($reponseCode);
        } else {
            http_response_code(200);
        }
        echo json_encode($resp);
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $post_body = file_get_contents("php://input");

    if (isset($headers["token"])) {
        $token = $headers["token"];

        # Enviamos los datos
        $resp = $_usuario->put($post_body, $token);
        if (isset($resp["result"]["code"])) {
            $reponseCode = $resp["result"]["code"];
            http_response_code($reponseCode);
        } else {
            http_response_code(200);
        }
        echo json_encode($resp);
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    // $headers = getallheaders();

    // if (isset($headers["token"]) && isset($headers["idcodereg"])) {
    //     $send = [
    //         "token" => $headers["token"],
    //         "idcodereg" => $headers["idcodereg"]
    //     ];
    //     $post_body = json_encode($send);
    // } else {
    //     $post_body = file_get_contents("php://input");
    // }
    if (isset($headers["token"])) {
        $token = $headers["token"];

        $post_body = file_get_contents("php://input");
        // # Enviamos los datos
        $resp = $_usuario->delete($post_body, $token);
        if (isset($resp["result"]["code"])) {
            $reponseCode = $resp["result"]["code"];
            http_response_code($reponseCode);
        } else {
            http_response_code(200);
        }
        echo json_encode($resp);
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else {

    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
}
