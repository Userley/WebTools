<?php
require_once 'clases/respuestas.class.php';
require_once 'clases/consumo.class.php';
require_once 'clases/conexion/configCors.php';

$headers = getallheaders();

$_respuestas = new respuestas;
$_consumo = new consumo;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $valor = @array_pop(array_filter(explode('/', $_SERVER["REQUEST_URI"])));

    if (isset($headers["token"])) {
        $token = $headers["token"];

        if (isset($_GET["anios"])) {
            $lstconsumo = $_consumo->listarAnios($token);
            echo json_encode($lstconsumo);
            http_response_code(200);
        } elseif (isset($_GET["meses"])) {
            $lstconsumo = $_consumo->listarMeses($token);
            echo json_encode($lstconsumo);
            http_response_code(200);
        } elseif ($valor == "consumo") {

            $lstconsumo = $_consumo->listarConsumos($token);
            echo json_encode($lstconsumo);
            http_response_code(200);
        } else {
            if (isset($_GET["id"])) {
                $consumoId = $_GET["id"];
                $datosCodeUtil = $_consumo->listarDetalleConsumo($consumoId, $token);
                echo json_encode($datosCodeUtil);
                http_response_code(200);
                return;
            }
        }
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $post_body = file_get_contents("php://input");

    if (isset($headers["token"])) {
        $token = $headers["token"];

        # Enviamos los datos
        $resp = $_consumo->post($post_body, $token);
        if (isset($resp["result"]["code"])) {
            $reponseCode = $resp["result"]["code"];
            http_response_code($reponseCode);
        } else {
            http_response_code(200);
        }
        echo json_encode($resp);
    } else {
        echo  json_encode($_respuestas->error_401());
        http_response_code(400);
    }

    //} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    //     $post_body = file_get_contents("php://input");

    //     if (isset($headers["token"])) {
    //         $token = $headers["token"];

    //         # Enviamos los datos
    //         $resp = $_consumo->put($post_body, $token);
    //         if (isset($resp["result"]["code"])) {
    //             $reponseCode = $resp["result"]["code"];
    //             http_response_code($reponseCode);
    //         } else {
    //             http_response_code(200);
    //         }
    //         echo json_encode($resp);
    //     } else {
    //         echo  json_encode($_respuestas->error_401());
    //         http_response_code(400);
    //     }
    // } else if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    //     // $headers = getallheaders();

    //     // if (isset($headers["token"]) && isset($headers["idcodereg"])) {
    //     //     $send = [
    //     //         "token" => $headers["token"],
    //     //         "idcodereg" => $headers["idcodereg"]
    //     //     ];
    //     //     $post_body = json_encode($send);
    //     // } else {
    //     //     $post_body = file_get_contents("php://input");
    //     // }
    //     if (isset($headers["token"])) {
    //         $token = $headers["token"];

    //         $post_body = file_get_contents("php://input");
    //         // # Enviamos los datos
    //         $resp = $_consumo->delete($post_body, $token);
    //         if (isset($resp["result"]["code"])) {
    //             $reponseCode = $resp["result"]["code"];
    //             http_response_code($reponseCode);
    //         } else {
    //             http_response_code(200);
    //         }
    //         echo json_encode($resp);
    //     } else {
    //         echo  json_encode($_respuestas->error_401());
    //         http_response_code(400);
    //     }
} else {

    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
}
