<?php
class conexion
{
    private $server;
    private $user;
    private $password;
    private $database;
    private $port;
    private $conex;

    function __construct()
    {
        $listadatos = $this->datosConexion();
        foreach ($listadatos as $key => $value) {
            $this->server = $value['server'];
            $this->user = $value['user'];
            $this->password = $value['password'];
            $this->database = $value['database'];

            $this->conex = new mysqli($this->server, $this->user, $this->password, $this->database, $this->port) or die("Error de Conexion");
            if ($this->conex->connect_errno) {
                echo "Problemas con conexión";
            }
        }
    }

    private function datosConexion()
    {
        $direccion = dirname(__FILE__);
        $jsondata = file_get_contents($direccion . "/" . "config");
        return json_decode($jsondata, true);
    }

    private function convertirUTF8($array)
    {
        array_walk_recursive($array, function (&$item, $key) {
            if (!mb_detect_encoding($item, 'utf-8', true)) {
                $item = utf8_encode($item);
            }
        });
        return $array;
    }

    public function obtenerDatos($SQLquery)
    {
        $results = $this->conex->query($SQLquery);
        $resultsArray = array();
        foreach ($results as $key) {
            $resultsArray[] = $key;
        }
        return $this->convertirUTF8($resultsArray);
    }

    public function nonQuery($sqlStr)
    {
        $results = $this->conex->query($sqlStr);
        return $results;
    }


    /* INSERTAR REGISTROS */
    public function nonQueryId($sqlStr)
    {
        $results = $this->conex->query($sqlStr);
        $filas = $this->conex->affected_rows;
        if ($filas >= 1) {
            return $this->conex->insert_id;
        } else {
            return 0;
        }
    }

    // ENCRIPTAR DATOS

    protected function encriptar($string)
    {
        return md5($string);
    }
}
