<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';


class lenguaje extends conexion
{

    private $table = "lenguaje";
    private $token = "";

    public function listarLenguajes($token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            $query = "SELECT idlenguaje,nombre,logo from " . $this->table ;
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function buscarToken()
    {
        $query = "SELECT idtoken, idusuario, estado FROM usuarios_token WHERE Token = '" . $this->token . "' AND estado = 1";
        $resp = parent::obtenerDatos($query);

        if ($resp) {
            return  $resp;
        } else {
            return 0;
        }
    }

    private function actualizarToken($tokenId)
    {
        $date = date("Y-m-d H:i");
        $query = "UPDATE usuarios_token SET fecha = '$date' WHERE idtoken = '$tokenId'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }
}
