<?php
require_once "clases/conexion/conexion.php";

$conexion = new conexion;

// $query = "INSERT INTO usuario (nombres,apellidos,avatar,nickname,correo,celular,fechanac,tipousuario) VALUES ('Diana','Monsalve','DianisXD','Dianis','diana123@gmail.com','914155839','1987-05-05','T0002')";

// var_dump($conexion->nonQueryId($query));
?>

Hola index