<?php
require_once 'conexion/conexion.php';
require_once 'respuestas.class.php';


class link extends conexion
{

    private $table = "utileslink";
    private $token = "";
    private $idutillnk = 0;
    private $idtipolnk = 1;
    private $nombre = "";
    private $descripcion = "";
    private $link = "";
    private $creador = "";
    private $fecharegistro = "";
    private $idusuario = 1;
    private $img = "";
    private $calificacion = 0;
    private $estado = 1;

    public function listarLinks($pagina = 0, $token)
    {
        $_respuesta = new respuestas;
        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            $inicio = 0;
            $cantidad = 100;
            if ($pagina > 1) {
                $inicio = ($cantidad * ($pagina - 1)) + 1;
                $cantidad = $cantidad * $pagina;
            }

            $query = "SELECT l.idutillnk,l.nombre,l.descripcion,l.link,cl.idcatlink,cl.descripcion as categoria, l.creador, l.fecharegistro, l.idusuario, l.img,l.calificacion,tp.idtipolnk,tp.icono,tp.descripcion as dlink, l.estado from " . $this->table . " l INNER JOIN tipo_link tp ON tp.idtipolnk = l.idtipolnk INNER JOIN categorias_link cl ON cl.idcatlink = l.idcatlink WHERE l.estado = " . $this->estado . " and l.idusuario = " . $this->idusuario . " ORDER BY l.fecharegistro DESC";// LIMIT $inicio,$cantidad";
            $datos = parent::obtenerDatos($query);
            return ($datos);
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    public function obtenerLink($id)
    {
        $query = "SELECT l.idutillnk,l.nombre,l.descripcion,l.link,cl.idcatlink,cl.descripcion as categoria, l.creador, l.fecharegistro, l.idusuario, l.img,l.calificacion,tp.idtipolnk,tp.icono,tp.descripcion as dlink, l.estado from " . $this->table . " l INNER JOIN tipo_link tp ON tp.idtipolnk = l.idtipolnk INNER JOIN categorias_link cl ON cl.idcatlink = l.idcatlink WHERE idutillnk = '$id' ";
        return parent::obtenerDatos($query);
    }


    public function post($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['titulo'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                $this->nombre = $datos['nombre'];
                if (isset($datos['descripcion'])) {
                    $this->descripcion = $datos['descripcion'];
                }
                if (isset($datos['link'])) {
                    $this->link = $datos['link'];
                }
                if (isset($datos['creador'])) {
                    $this->creador = $datos['creador'];
                }
                if (isset($datos['fecharegistro'])) {
                    $this->fecharegistro = $datos['fecharegistro'];
                }
                if (isset($datos['idusuario'])) {
                    $this->idusuario = $datos['idusuario'];
                }
                if (isset($datos['img'])) {
                    $this->img = $datos['img'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->insertarLink();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idutillnk" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function insertarLink(){

        $query = "INSERT INTO " . $this->table . " (idutillnk, idtipolnk, nombre, descripcion, link, creador, fecharegistro, idusuario, img,calificacion, estado) VALUES 
                                                    ('1','1','$this->nombre','$this->descripcion','$this->link','$this->creador','$this->fecharegistro','$this->idusuario','$this->img','$this->calificacion',$this->estado)";
        $resp = parent::nonQueryId($query);
        if ($resp) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function put($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['titulo'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                $this->idutillnk = $datos['idutillnk'];
                $this->nombre = $datos['nombre'];
                if (isset($datos['descripcion'])) {
                    $this->descripcion = $datos['descripcion'];
                }
                if (isset($datos['link'])) {
                    $this->link = $datos['link'];
                }
                if (isset($datos['creador'])) {
                    $this->creador = $datos['creador'];
                }
                if (isset($datos['fecharegistro'])) {
                    $this->fecharegistro = $datos['fecharegistro'];
                }
                if (isset($datos['idusuario'])) {
                    $this->idusuario = $datos['idusuario'];
                }
                if (isset($datos['img'])) {
                    $this->img = $datos['img'];
                }
                if (isset($datos['estado'])) {
                    $this->estado = $datos['estado'];
                }

                $resp = $this->actualizarLink();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idutillnk" => $this->idutillnk,
                        "updated" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function actualizarLink()
    {

        $query = "UPDATE " . $this->table . " SET idtipolnk = '$this->idtipolnk', 
                                                    nombre = '$this->nombre', 
                                                    descripcion = '$this->descripcion', 
                                                    link = '$this->link', 
                                                    creador = '$this->creador', 
                                                    fecharegistro = '$this->fecharegistro',
                                                    img = $this->img,
                                                    calificacion = $this->calificacion,
                                                    estado = $this->estado,

                                                WHERE idutillnk = '$this->idutillnk'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    public function delete($json, $token)
    {
        $_respuesta = new respuestas;
        $datos = json_decode($json, true);

        if (!isset($token)) {
            return $_respuesta->error_401();
        } else {
            $this->token = $token;
            $arrayToken = $this->buscarToken();
        }
        if ($arrayToken) {
            if (!isset($datos['idutillnk'])) { //|| !isset($datos['referencia']) || !isset($datos['solucion']) || !isset($datos['fechareg']) || !isset($datos['tag'])) {
                return $_respuesta->error_400();
            } else {

                $this->idutillnk = $datos['idutillnk'];


                $resp = $this->eliminarLink();
                if ($resp) {
                    $respuesta = $_respuesta->response;
                    $respuesta["result"] = array(
                        "idutillnk" => $this->idutillnk,
                        "deleted" => $resp
                    );
                    return $respuesta;
                } else {
                    return $_respuesta->error_500();
                }
            }
        } else {
            return $_respuesta->error_401("El token enviado no es válido o caducó");
        }
    }

    private function eliminarLink()
    {
        $query = "DELETE FROM " . $this->table . " WHERE idutillnk = '$this->idutillnk'";
        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }


    private function buscarToken()
    {
        $query = "SELECT idtoken, idusuario, estado FROM usuarios_token WHERE Token = '" . $this->token . "' AND estado = 1";
        $resp = parent::obtenerDatos($query);

        if ($resp) {
            return  $resp;
        } else {
            return 0;
        }
    }

    private function actualizarToken($tokenId)
    {
        $date = date("Y-m-d H:i");
        $query = "UPDATE usuarios_token SET fecha = '$date' WHERE idtoken = '$tokenId'";

        $resp = parent::nonQuery($query);
        if ($resp >= 1) {
            return $resp;
        } else {
            return 0;
        }
    }
}
